<div class="container-fluid bg-dark text-light ">
   <p class="text-center">Copyright iDiscuss Coding Forums 2022 | All Rights Reserved</p> 
</div>