<?php
$server = "localhost";
$database = "idiscuss";
$username = "root";
$password = "";

$conn = mysqli_connect($server, $username, $password, $database);